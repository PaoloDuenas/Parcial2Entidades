using System;
using System.Windows.Forms;

namespace Parcial02
{
    public partial class FrmCreateUser : Form
    {
        public FrmCreateUser()
        {
            InitializeComponent();
        }

        private void FrmCreateUser_Load(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }
    }
}