namespace Parcial02.Entities.Specialties
{
    public class Specialty
    {
        public int id { get; set; }

        public string name { get; set; }


        public Specialty()
        {
            
        }

        public Specialty(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }
}