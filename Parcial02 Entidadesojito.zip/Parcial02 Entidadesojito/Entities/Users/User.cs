using Parcial02.Entities.SecurityQuestions;

namespace Parcial02.Entities.Users
{
    public class User
    {
        public string id { get; set; }

        public string userfullname { get; set; }

        public string password { get; set; }

        public SecurityQuestion securityquestion { get; set; }

        public string securityanswer { get; set; }

        public User()
        {
            
        }

        public User(string id, string fullName, string password, SecurityQuestion securityquestion, string securityAnswer)
        {
            this.id = id;
            this.userfullname = userfullname;
            this.password = password;
            this.securityquestion = securityquestion;
            this.securityanswer = securityAnswer;
        }
    }
}