using Parcial02.Entities.Specialties;
using Parcial02.Entities.Users;

namespace Parcial02.Entities.Reservations
{
    public class Reservation
    {
        public int id { get; set; }

        public User userid { get; set; }

        public Specialty specialtyid { get; set; }

        public string date { get; set; }

        public string time { get; set; }


        public Reservation()
        {
            
        }


        public Reservation(User userid, Specialty specialtyid, string date, string time)
        {
            this.userid = userid;
            this.specialtyid = specialtyid;
            this.date = date;
            this.time = time;
        }
    }
}