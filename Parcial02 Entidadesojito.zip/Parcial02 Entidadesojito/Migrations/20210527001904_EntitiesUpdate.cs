﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Parcial02.Migrations
{
    public partial class EntitiesUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FullName",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "SpecialtyId",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Reservations");

            migrationBuilder.RenameColumn(
                name: "SecurityAnswer",
                table: "Users",
                newName: "securityanswer");

            migrationBuilder.RenameColumn(
                name: "Password",
                table: "Users",
                newName: "password");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Users",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "SecurityQuestion",
                table: "Users",
                newName: "userfullname");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Specialties",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Specialties",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "Question",
                table: "SecurityQuestions",
                newName: "question");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "SecurityQuestions",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "Time",
                table: "Reservations",
                newName: "time");

            migrationBuilder.RenameColumn(
                name: "Date",
                table: "Reservations",
                newName: "date");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Reservations",
                newName: "id");

            migrationBuilder.AddColumn<int>(
                name: "securityquestionid",
                table: "Users",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "specialtyidid",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "useridid",
                table: "Reservations",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_securityquestionid",
                table: "Users",
                column: "securityquestionid");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_specialtyidid",
                table: "Reservations",
                column: "specialtyidid");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_useridid",
                table: "Reservations",
                column: "useridid");

            migrationBuilder.AddForeignKey(
                name: "FK_Reservations_Specialties_specialtyidid",
                table: "Reservations",
                column: "specialtyidid",
                principalTable: "Specialties",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Reservations_Users_useridid",
                table: "Reservations",
                column: "useridid",
                principalTable: "Users",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_SecurityQuestions_securityquestionid",
                table: "Users",
                column: "securityquestionid",
                principalTable: "SecurityQuestions",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reservations_Specialties_specialtyidid",
                table: "Reservations");

            migrationBuilder.DropForeignKey(
                name: "FK_Reservations_Users_useridid",
                table: "Reservations");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_SecurityQuestions_securityquestionid",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_securityquestionid",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Reservations_specialtyidid",
                table: "Reservations");

            migrationBuilder.DropIndex(
                name: "IX_Reservations_useridid",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "securityquestionid",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "specialtyidid",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "useridid",
                table: "Reservations");

            migrationBuilder.RenameColumn(
                name: "securityanswer",
                table: "Users",
                newName: "SecurityAnswer");

            migrationBuilder.RenameColumn(
                name: "password",
                table: "Users",
                newName: "Password");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Users",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "userfullname",
                table: "Users",
                newName: "SecurityQuestion");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "Specialties",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Specialties",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "question",
                table: "SecurityQuestions",
                newName: "Question");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "SecurityQuestions",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "time",
                table: "Reservations",
                newName: "Time");

            migrationBuilder.RenameColumn(
                name: "date",
                table: "Reservations",
                newName: "Date");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Reservations",
                newName: "Id");

            migrationBuilder.AddColumn<string>(
                name: "FullName",
                table: "Users",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SpecialtyId",
                table: "Reservations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "Reservations",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
